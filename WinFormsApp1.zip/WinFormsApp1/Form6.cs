﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ClassLibrary2;

namespace WinFormsApp1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
   
        private void button1_Click_1(object sender, EventArgs e)
        {

            Planet list = new ArtificialSatellite(int.Parse(textBox1.Text), textBox2.Text, textBox3.Text, dateTimePicker1.Value);
            ArtificialSatellite lt = (ArtificialSatellite)list; // низходящее ЯВНОЕ преобразование
            //lt.ArtSatName = "adad";
            //list.ArtSatName="dsdas"; недоступная часть функциональности дочернего класса
            if (lt.ArtSatName != null )
            {
                richTextBox1.Text = string.Format("Иск. спутник планеты: {1}, Номер {4}\nНазвание спутника: {0}\n" + "Дата рождения: {2}\nДата смерти: {3}\n\n",lt.ArtSatName,list.PlanetName, lt.Date, lt.Term(), lt.PlanetId);
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            textBox1.Text= 0.ToString();
            ArtificialSatellite s1 = new ArtificialSatellite();
            Satellite s = s1; // восходящее преобразование
            s.Date= DateTime.Now;
            richTextBox1.Text = "ДАТА: " + s.Date + "\n\n"; 
            object e1 = new ArtificialSatellite(3,"ada", "adad", DateTime.Now);
            object e2 = new Satellite(3, "adasd");
            object e3 = new Planet("None");

            richTextBox1.Text += e1.ToString() + "\n" + e2.GetType() + "\n" + e3.GetHashCode() + "\n";
            //object - базовый тип для всех остальных типов, преобразование автоматическое.
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox1.Text = 0.ToString();
        }
    }
}
