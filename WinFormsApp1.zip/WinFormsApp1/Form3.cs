﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//using ClassLibrary_OPLaba;
using ClassLibrary1;
using ClassLibrary2;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Planet list = new Planet(int.Parse(numericUpDown2.Text), textBox1.Text, dateTimePicker1.Value);
            if (textBox1.Text == string.Empty)
            {
                Planet list2 = new Planet("Планета не введена\n");
                richTextBox1.Text = list2.Name;
            }
            else
            {
                Lab3 p1 = new Lab3();
                list.Date = dateTimePicker1.Value;
                p1.Number = (int)numericUpDown1.Value;
                p1.word = textBox3.Text;
                richTextBox1.Text += string.Format("№{3}:\nНазвание планеты: {0}\nРадиус: {1}\nАтмосфера: {2}\nДата рождения: {4}\n\n ", list.Name, list.Distance,p1.word, p1.Number, list.Date.ToShortDateString());
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Planet l = new Planet();
            Lab3 p = new Lab3();
            richTextBox1.Text = string.Format("Пример:\n№{3}:\nНазвание планеты: {0}\nРадиус: {1}\nАтмосфера: {2}\nДата рождения: {4}\n\n", l.Name, l.Distance, p.word, p.Number, l.Date.ToShortDateString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

   
    } 
}
