﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//using ClassLibrary_OPLaba;
using ClassLibrary1;
using ClassLibrary2;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            Planet p1 = new Planet();
            p1.PlanetId = (int)numericUpDown1.Value;
            p1.PlanetName = textBox1.Text;
            if (textBox1.Text == string.Empty)
            {
                Planet p2 = new Planet("Не введены данные\n");
                richTextBox2.Text = p2.PlanetName;
            }
            else
            {
                PlanetProp PP;
                PP.AtmoComp = textBox2.Text;
                PP.radius = 57;
                richTextBox2.Text += string.Format("Номер планеты: {2}, Название планеты: {1}, Галактика {0}, состав атмосферы {3}, Радиус: {4}\n\n", Planet.SolarSys, p1.PlanetName, p1.PlanetId, PP.AtmoComp, PP.radius);
                PlanetProp pl1 = new PlanetProp { AtmoComp = "Кислород", radius = 51 };
                richTextBox2.Text += string.Format("Номер планеты: 2134124, Название планеты: Земля, Галактика {0}, состав атмосферы {1}, Радиус: {2}\n\n", Planet.SolarSys,pl1.AtmoComp, pl1.radius);
                PlanetProp pl = new PlanetProp("Неизвестно", 53);
                richTextBox2.Text += string.Format("Номер планеты: 224, Название планеты: Нибиру, Галактика {0}, состав атмосферы {1}, Радиус: {2}\n\n", Planet.SolarSys, pl.AtmoComp, pl.radius);

            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
            BackColor = Planet.back;
            Planet p1 = new Planet(0," - ");
            PlanetProp p = new PlanetProp();
            richTextBox2.Text = string.Format("Пример:\nНомер планеты: {2}, Название планеты: {1}, Галактика {0}, состав атмосферы {1}, Радиус: {4}\n\n", Planet.SolarSys,p1.PlanetName, p1.PlanetId,p.AtmoComp, p.radius);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox2.Clear();
        }
    }
}
