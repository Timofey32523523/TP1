﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ClassLibrary2;
namespace WinFormsApp1
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        Interface1 order = new SolarSystem();
        List<SolarSystem> list = new List<SolarSystem>();

        private static void DisplayMessage(string message)
        {
            MessageBox.Show(message);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ((SolarSystem)order).PlanetName = textBox1.Text;
            ((SolarSystem)order).Added(int.Parse(textBox2.Text));

            order.DateOfBirth = dateTimePicker1.Value;

            list.Add(new SolarSystem(textBox1.Text));
            listBox1.DataSource = null;
            listBox1.DataSource = list;
            listBox1.DisplayMember = "PlNm";

            richTextBox1.Text += String.Format("НАЗВАНИЕ ПЛАНЕТЫ: {0}\nГРАВИТАЦИЯ: {1}\nДАТА РОЖДЕНИЯ:{2}\n\n",
                ((SolarSystem)order).PlanetName, ((SolarSystem)order).PlanetId, order.DateOfBirth.ToShortDateString());

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ((SolarSystem)order).Report += DisplayMessage;
            order = (SolarSystem)order;
            order.Summ(order.Rad);

            richTextBox1.Text += "\nГравитация: ";

            richTextBox1.Text += string.Format(order.Rad.ToString());

            richTextBox1.Text += "\n";
        }

      
    }

}

