﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//using ClassLibrary_OPLaba;
using ClassLibrary1;
using ClassLibrary2;

namespace WinFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
       
        List<Planet> collect = new List<Planet>();
        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox3.Text = null;
            textBox4.Text = null;

        }

        private void button2_Click(object sender, EventArgs e)
        {           
            collect.Add(new Planet(textBox3.Text, int.Parse(textBox4.Text), dateTimePicker1.Value));
            listBox1.DataSource = null;
            listBox1.DataSource = collect;
            listBox1.DisplayMember = "Name";
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            collect.Add(new Planet("Марс", 150, new DateTime(2024, 11, 30)));
            listBox1.DataSource = collect;
            listBox1.DisplayMember = "Name";
            textBox1.DataBindings.Add("Text", collect, "Name");
            dateTimePicker2.DataBindings.Add("Value", collect, "date");
            textBox5.DataBindings.Add("Text", collect, "distance");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                Planet photo = new Planet(openFileDialog1.FileName);
                photo.ShowFoto(pictureBox1);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image=null;
        }
    }
}

