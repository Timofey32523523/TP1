﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ClassLibrary2;

namespace WinFormsApp1
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System1 ord = new System1((int)numericUpDown2.Value, (int)numericUpDown1.Value); // композиция
            richTextBox1.Text += "Композиция:\n";
            richTextBox1.Text += String.Format("НОМЕР: {0}\nId: {1}\n\n", ord.Num, ord.Planet1.PlanetId);

            Planet god = new Planet((int)numericUpDown1.Value, textBox1.Text);    // агрегация
            System1 System = new System1((int)(numericUpDown2.Value), god,"Sis");
            
            richTextBox1.Text += "Агрегация:\n";
            richTextBox1.Text += System.ToString()+"\n";
            god.PlanetName = "Другое название";
            richTextBox1.Text += System.ToString();

            Assoc added = new Assoc(dateTimePicker1.Value,"Sssr");         //ассоциация
            added.Planet2 = new Planet((int)numericUpDown1.Value, textBox1.Text);
            added.Planet2.cosmic = textBox2.Text;
            richTextBox1.Text += "Ассоциация:\n";
            richTextBox1.Text += added.ToString();
        }
    }
}
