﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Event a = new Event(1000);
            a.Report += DisplayMessage;
            a.Num_Add(500);
            richTextBox1.Text += string.Format("Ресурсов {0}\n", a.Number);
            a.Added(700);
            richTextBox1.Text += string.Format("Ресурсов {0}\n", a.Number);
            a.Added(1000);
            richTextBox1.Text += string.Format("Ресурсов {0}\n", a.Number);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            Event a = new Event();
            a.Report += DisplayMessage;
            a.Num_Add(int.Parse(textBox1.Text));
            a.Added(int.Parse(textBox2.Text));
            richTextBox1.Text += string.Format("Ресурсов {0}\n", a.Number);

        }


        private static void DisplayMessage(object sender,EventEventArgs e)
        {
            MessageBox.Show(string.Format("{0} {1}",e.Message, e.Number));
        }
    }
}
