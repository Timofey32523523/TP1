﻿namespace WinFormsApp1
{
    partial class Form0
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.labsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.labsToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // labsToolStripMenuItem
            // 
            this.labsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lab1ToolStripMenuItem,
            this.lab2ToolStripMenuItem,
            this.lab3ToolStripMenuItem,
            this.lab4ToolStripMenuItem,
            this.lab5ToolStripMenuItem,
            this.lab6ToolStripMenuItem,
            this.lab7ToolStripMenuItem,
            this.lab8ToolStripMenuItem,
            this.lab9ToolStripMenuItem,
            this.lab10ToolStripMenuItem,
            this.lab11ToolStripMenuItem});
            this.labsToolStripMenuItem.Name = "labsToolStripMenuItem";
            this.labsToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.labsToolStripMenuItem.Text = "Labs";
            // 
            // lab1ToolStripMenuItem
            // 
            this.lab1ToolStripMenuItem.Name = "lab1ToolStripMenuItem";
            this.lab1ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab1ToolStripMenuItem.Text = "Lab1";
            this.lab1ToolStripMenuItem.Click += new System.EventHandler(this.lab1ToolStripMenuItem_Click);
            // 
            // lab2ToolStripMenuItem
            // 
            this.lab2ToolStripMenuItem.Name = "lab2ToolStripMenuItem";
            this.lab2ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab2ToolStripMenuItem.Text = "Lab2";
            this.lab2ToolStripMenuItem.Click += new System.EventHandler(this.lab2ToolStripMenuItem_Click);
            // 
            // lab3ToolStripMenuItem
            // 
            this.lab3ToolStripMenuItem.Name = "lab3ToolStripMenuItem";
            this.lab3ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab3ToolStripMenuItem.Text = "Lab3";
            this.lab3ToolStripMenuItem.Click += new System.EventHandler(this.lab3ToolStripMenuItem_Click_1);
            // 
            // lab4ToolStripMenuItem
            // 
            this.lab4ToolStripMenuItem.Name = "lab4ToolStripMenuItem";
            this.lab4ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab4ToolStripMenuItem.Text = "Lab4";
            this.lab4ToolStripMenuItem.Click += new System.EventHandler(this.lab4ToolStripMenuItem_Click);
            // 
            // lab5ToolStripMenuItem
            // 
            this.lab5ToolStripMenuItem.Name = "lab5ToolStripMenuItem";
            this.lab5ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab5ToolStripMenuItem.Text = "Lab5";
            this.lab5ToolStripMenuItem.Click += new System.EventHandler(this.lab5ToolStripMenuItem_Click);
            // 
            // lab6ToolStripMenuItem
            // 
            this.lab6ToolStripMenuItem.Name = "lab6ToolStripMenuItem";
            this.lab6ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab6ToolStripMenuItem.Text = "Lab6";
            this.lab6ToolStripMenuItem.Click += new System.EventHandler(this.lab6ToolStripMenuItem_Click);
            // 
            // lab7ToolStripMenuItem
            // 
            this.lab7ToolStripMenuItem.Name = "lab7ToolStripMenuItem";
            this.lab7ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab7ToolStripMenuItem.Text = "Lab7";
            this.lab7ToolStripMenuItem.Click += new System.EventHandler(this.lab7ToolStripMenuItem_Click);
            // 
            // lab8ToolStripMenuItem
            // 
            this.lab8ToolStripMenuItem.Name = "lab8ToolStripMenuItem";
            this.lab8ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab8ToolStripMenuItem.Text = "Lab8";
            this.lab8ToolStripMenuItem.Click += new System.EventHandler(this.lab8ToolStripMenuItem_Click);
            // 
            // lab9ToolStripMenuItem
            // 
            this.lab9ToolStripMenuItem.Name = "lab9ToolStripMenuItem";
            this.lab9ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab9ToolStripMenuItem.Text = "Lab9";
            this.lab9ToolStripMenuItem.Click += new System.EventHandler(this.lab9ToolStripMenuItem_Click_1);
            // 
            // lab10ToolStripMenuItem
            // 
            this.lab10ToolStripMenuItem.Name = "lab10ToolStripMenuItem";
            this.lab10ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab10ToolStripMenuItem.Text = "Lab10";
            this.lab10ToolStripMenuItem.Click += new System.EventHandler(this.lab10ToolStripMenuItem_Click);
            // 
            // lab11ToolStripMenuItem
            // 
            this.lab11ToolStripMenuItem.Name = "lab11ToolStripMenuItem";
            this.lab11ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.lab11ToolStripMenuItem.Text = "Lab11";
            this.lab11ToolStripMenuItem.Click += new System.EventHandler(this.lab11ToolStripMenuItem_Click);
            // 
            // Form0
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.Name = "Form0";
            this.Text = "Menu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem labsToolStripMenuItem;
        private ToolStripMenuItem lab1ToolStripMenuItem;
        private ToolStripMenuItem lab2ToolStripMenuItem;
        private ToolStripMenuItem lab3ToolStripMenuItem;
        private ToolStripMenuItem lab4ToolStripMenuItem;
        private ToolStripMenuItem lab5ToolStripMenuItem;
        private ToolStripMenuItem lab6ToolStripMenuItem;
        private ToolStripMenuItem lab7ToolStripMenuItem;
        private ToolStripMenuItem lab8ToolStripMenuItem;
        private ToolStripMenuItem lab9ToolStripMenuItem;
        private ToolStripMenuItem lab10ToolStripMenuItem;
        private ToolStripMenuItem lab11ToolStripMenuItem;
    }
}