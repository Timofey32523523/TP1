﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            pictureBox1.Image = null;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ArtificialSatellite file1 = new ArtificialSatellite(textBox1.Text);
            file1.WriteTOFile();
            
        }

        private void button2_Click(object sender, EventArgs e)
        { 
                if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
                {
                ArtificialSatellite art1 = new ArtificialSatellite(openFileDialog1.FileName,textBox1.Text,dateTimePicker1.Value);
                art1.ShowFoto(pictureBox1);
                }
            
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            textBox1.Text = "def";
        }
    }
}

