﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;
namespace WinFormsApp1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            Sat font = new Sat();
            if (fontDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            font.ChangeFont(ActiveForm, fontDialog1.Font, fontDialog1.Color);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sat color = new Sat();
            if (colorDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            color.ChangeColor(richTextBox1,textBox1, textBox2,colorDialog1.Color);
            color.ChangeColor(button2);
            Sat color1 = new Sat(25);
            richTextBox1.Text= color1.id.ToString();   

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Sat txt = new Sat(int.Parse(textBox1.Text), textBox2.Text);
            richTextBox1.Text+=txt.NameText();
            richTextBox1.Text += "\n";


        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text=null;
           
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            textBox1.Text=0.ToString();
        }
    }
}
