﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ClassLibrary2;
namespace WinFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

      

        private void richTextBox1_MouseHover(object sender, EventArgs e)
        {
            Planet list = new Planet(textBox2.Text, int.Parse(textBox3.Text), dateTimePicker1.Value);
            list.ExampleText(richTextBox1, i:15);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Planet file1 = new Planet();
            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                file1.path = openFileDialog1.FileName;
                richTextBox1.Text = file1.ReadFromFile();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Planet file2 = new Planet(textBox1.Text, textBox2.Text, int.Parse(textBox3.Text), dateTimePicker1.Value);
            if (saveFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                file2.path = saveFileDialog1.FileName;
                file2.WriteTOFile();
            }
        }

      

        private void button3_Click(object sender, EventArgs e)
        {
            Planet library = new Planet(textBox1.Text, textBox2.Text, int.Parse(textBox3.Text), dateTimePicker1.Value);
            listBox1.DataSource = library.Rate;
            listBox1.DisplayMember = "PlanetName";
            richTextBox2.Text += library.AverageRadius(/*ref*/ library.Amount, library.Rate) + " " + Convert.ToString(library.Amount) + " ";

            library.AverageRadius(library.Rate, out library.result, out library.resume);
            richTextBox2.Text += library.result + " " + library.resume + " ";
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox3.Text = 0.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = null;
            richTextBox2.Text = null;
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            listBox1.Text = null;

        }
    }
}

